-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 13, 2023 at 06:23 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.1.17

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `roots`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(15) NOT NULL,
  `email` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `username` varchar(25) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `password` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `email`, `username`, `password`) VALUES
(1, 'admin@roots.info', 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `advices`
--

CREATE TABLE `advices` (
  `A_id` int(11) NOT NULL,
  `A_title` varchar(500) NOT NULL,
  `A_details` varchar(1500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `advices`
--

INSERT INTO `advices` (`A_id`, `A_title`, `A_details`) VALUES
(1, '1. Choose plants based on your light', 'Are the plants you love the ones you can have?\r\nOur #1 rule of (green) thumb is to determine the amount of natural light your space receives and to choose your plant accordingly. If you\'re not sure just by looking, start by figuring out which direction your windows face. South-facing windows give bright light, east & west-facing windows give moderate light, and north-facing windows give low light. If something outside your window for example, a large tree or building could obstruct sunlight, make sure to consider that, too. Most houseplants prefer bright, indirect sunlight, but many can tolerate lower light levels. If the sun is intense through your windows, you may want to add a sheer curtain to diffuse the light. Cacti and some succulents like aloe can handle brighter, direct sunlight. You don\'t want to overexpose or underexpose any plant so keep an eye on them if they\'re in very bright or very low light.'),
(2, '2. Pick plants that work with your schedule', 'A busy work schedule, social life, and general forgetfulness can lead to unintentional plant neglect. It\'s okay. Some plants can handle that kind of lifestyle. A jetsetter like yourself will enjoy the resilience of low-maintenance and drought-tolerant succulents, all pretty low-key, as long as they have enough light (bright and low light respectively). These should keep looking their best when you return from your next trip. If you\'ve got more time, you can try a few attention-loving air plants, orchids, or ferns. Like a mist for the face, an extra spritz of filtered water daily between waterings keeps humidity levels nice and balanced for these delicate plants.'),
(3, '3. Be mindful when watering', 'It\'s better to under-water your plants than to overwater. Too much water can lead to root rot. Ditch your watering schedule and water your plant only when it needs it. Check the potting mix or soil first to make sure it\'s dry at least 2 inches deep below the surface. If your soil looks dark in color, feels moist, and sticks to your finger, your plant has enough water to do its thing for now. How often you water will also change throughout the year. Plants need less water in the winter months when they\'re growing slower, the days are shorter, and the sunlight is less intense. If the heat is on and their soil is drying out quicker, they may need a bit more water. Wilting leaves or soil that looks pulled away from the sides of the planter are signs of a thirsty plant. Always use warm water because it absorbs best. Pour water directly on the soil around the base of the plant because plants absorb water from their roots. The only exception here is Epiphytes, like air plants, which absorb water through their leaves. You can also place a saucer under your planter if it has a drainage hole. After you water, let your plant soak up in access water that fills the saucer for a few hours before emptying it.'),
(4, '4. Raise humidity levels when needed', 'Staying true to your plant\'s natural environment will help your plant thrive indoors. Most tropical plants prefer high humidity and bright to moderate, indirect light. During the dry months of winter, grouping similar plants together helps to create a more humid microclimate. A humidifier can help too and it\'s great for humans (find more ways to increase humidity levels here). On the other hand, most desert dwellers like cacti and succulents prefer dry air and bright, direct light with no shade at all. They don\'t much care for humidity.'),
(5, '5. Always keep temperatures stable', 'Keep your plant\'s home environment as stable as possible. Extreme changes can stress plants out. Keep the temperature between 65 and 85 degrees F, and avoid placing your plants near radiators, A/C units, and forced-air vents, which can create hot or cold drafts.'),
(6, '6. Know when to skip the fertilizer', 'Be mindful when using fertilizer on your houseplants. Too much fertilizer can do more harm than good. Houseplants tend to not need fertilizer as often as outdoor plants do. If you do choose to fertilize your plant, it\'s best to do so during the growing season (early spring to early fall) and follow the general rule of thumb: \'Less is more\'. Most store-bought fertilizers should be diluted with water before use.\r\nIf you have had your plant for at least a year, you can fertilize it for the first time. We suggest using an all-purpose fertilizer. Always follow the instructions. If you\'ve just changed the soil, skip the fertilizer! Fresh soil has enough new nutrients.'),
(7, '7. What is the difference between bright, medium and low light plants', 'Bright light plants will do well in direct or strong sunlight for the most part of a day.\n\nMedium light plants should stay out of the direct sunlight. They should be placed in a bright room and will enjoy partial or filtered sunlight. \n\nLow light plants prefer to stay in the shade or to be displayed under fluorescent light.'),
(8, '8.What if my plants/planters arrived damaged', 'If your plant(s) or planter(s) arrive damaged, we will replace it free of charge.\r\nNotify us within 24 hours via email Roots.pl00@gmail.com and we will send a replacement asap. Please include pictures and order number.'),
(9, '9. What are the little dark flies swarming over the pots of my plants', 'They are probably fungus gnats. They are not very harmful to plants but very annoying to us:\r\nThese guys can come from anywhere - air vents, drain pipes, etc. They find nice warm and moist environment to lay their eggs in. Frequent or excessive watering encourages their development. You can usually get rid of them by reducing the frequency of watering and allowing the soil to dry more between watering.'),
(10, '10. What forms of payment does website accept', 'Our website accept cash payment, Credit card,  and Apple Pay.'),
(11, '11. If I counter a problem on the website, What should I do\n', 'Contact us through the social networking sites located in the footer of the website.'),
(12, '12. My email address has changed. How do I update this information to my current account', 'After logging in, click on your name appearing at the top of the screen from the right. It will redirect you to your personal page and edit all the data you wish to modify.');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `cart_id` int(5) NOT NULL,
  `Prod_type` varchar(50) NOT NULL,
  `O_id` int(3) NOT NULL,
  `I_id` int(3) NOT NULL,
  `T_id` int(3) NOT NULL,
  `quantity` int(100) NOT NULL,
  `Customer_id` int(15) NOT NULL,
  `Planter_id` int(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`cart_id`, `Prod_type`, `O_id`, `I_id`, `T_id`, `quantity`, `Customer_id`, `Planter_id`) VALUES
(44, 'Indoor', 0, 2, 0, 1, 8, 0);

-- --------------------------------------------------------

--
-- Table structure for table `cartnotlogin`
--

CREATE TABLE `cartnotlogin` (
  `cart_id` int(5) NOT NULL,
  `Prod_type` varchar(50) NOT NULL,
  `O_id` int(3) NOT NULL,
  `I_id` int(3) NOT NULL,
  `T_id` int(3) NOT NULL,
  `quantity` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `Customer_id` int(15) NOT NULL,
  `C_Fname` varchar(25) NOT NULL,
  `C_Lname` varchar(25) NOT NULL,
  `C_address` varchar(40) NOT NULL,
  `C_phone` varchar(15) NOT NULL,
  `C_email` varchar(30) NOT NULL,
  `C_birthdate` date NOT NULL,
  `C_Password` varchar(30) NOT NULL,
  `C_Gender` varchar(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`Customer_id`, `C_Fname`, `C_Lname`, `C_address`, `C_phone`, `C_email`, `C_birthdate`, `C_Password`, `C_Gender`) VALUES
(1, 'Noor', 'Almotawa', 'Mubarraz', '+966051234567', 'Noor@gimal.com', '1988-02-01', '1233Noor_', 'Female'),
(2, 'Fatimah', 'AlKhatam', 'Almansorah', '+966541456897', 'FK@gimal.com', '1988-01-01', '12345@@A', 'female'),
(3, 'Mohamed', 'AlAmeer', 'Alqarah', '+966051234567', 'Mohamed@gmail.com', '1988-01-01', '123456Mohamed*', 'male'),
(6, 'Lojain', 'Almoalem', 'Alhofuf', '+966509778686', 'lojain.74@hotmail.com', '2000-12-05', 'Lo123456789', 'female'),
(7, 'Mariya', 'AlAhmad', 'Dalwah', '+966598844445', 'Maria21@hotmail.com', '2002-03-22', 'Mary2345', 'female');

-- --------------------------------------------------------

--
-- Table structure for table `indoor`
--

CREATE TABLE `indoor` (
  `I_id` int(3) NOT NULL,
  `I_title` varchar(500) NOT NULL,
  `I_img` varchar(500) NOT NULL,
  `I_price` float NOT NULL,
  `I_quantity` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `indoor`
--

INSERT INTO `indoor` (`I_id`, `I_title`, `I_img`, `I_price`, `I_quantity`) VALUES
(1, '‎بوتس - (Epipremnum aureum)', 'img/indoor/1.jpg', 32, 14),
(2, 'كرمة المحبوب - (Philodendron scandens)', 'img/indoor/2.jpg', 35, 14),
(3, '‎بامبو - (Bamboo)', 'img/indoor/3.jpg', 20, 12),
(4, '‎‎جلد النمر - (Sansevieria)', 'img/indoor/4.jpg', 147.5, 13),
(5, 'زاميا - (Zamioculcas zamiifolia)', 'img/indoor/5.jpg', 103, 14),
(6, 'دراسينا - (Dracaena)', 'img/indoor/8.jpg', 188, 15),
(7, '‎‎نخيل اريكا - (Areca palm)', 'img/indoor/12.jpg', 66.2, 15),
(8, 'بونساي - (Bonsai)', 'img/indoor/13.jpg', 115, 15),
(9, 'الاشرعة البيضاء - (Spathiphyllum wallisii)', 'img/indoor/14.jpg', 74, 10),
(10, 'الكلانشو - (Kalanchoe blossfeldiana)', 'img/indoor/15.jpg', 28.75, 10),
(11, '‎‎‎انتوريوم - (Anthurium)', 'img/indoor/20.jpg', 79, 10),
(12, 'الجاردينيا - (Gardenia Jasminoides)', 'img/indoor/21.jpg', 38, 15),
(13, '‎الأجلونيما - (Silver Aglaonema)', 'img/indoor/6.jpg', 47, 14),
(14, 'الأجلونيما - (Pink Aglaonema)', 'img/indoor/7.jpg', 47, 11),
(15, 'فيتونيا - (Green Fittonia)', 'img/indoor/9.jpg', 89, 15),
(16, 'فيتونيا - (Dark Fittonia)', 'img/indoor/10.jpg', 89, 10),
(17, 'فيتونيا - (Pink Fittonia)', 'img/indoor/11.jpg', 89, 14),
(18, 'الأوركيد - (Purple Orchid)', 'img/indoor/16.jpg', 166, 12),
(19, 'الأوركيد - (Pink Orchid)', 'img/indoor/17.jpg', 166, 10),
(20, 'الأوركيد - (White Orchid)', 'img/indoor/18.jpg', 166, 14),
(21, 'الأوركيد - (Yellow Orchid)', 'img/indoor/19.jpg', 166, 23);

-- --------------------------------------------------------

--
-- Table structure for table `outdoor`
--

CREATE TABLE `outdoor` (
  `O_id` int(3) NOT NULL,
  `O_title` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `O_img` blob NOT NULL,
  `O_price` int(100) NOT NULL,
  `O_quantity` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `outdoor`
--

INSERT INTO `outdoor` (`O_id`, `O_title`, `O_img`, `O_price`, `O_quantity`) VALUES
(1, 'زهرة النرجس - ‎(Narcissus flower)', 0x696d672f6f7574646f6f722f312e6a7067, 69, 0),
(2, 'بلومباجو - (Plumbago flower)', 0x696d672f6f7574646f6f722f322e6a7067, 58, 10),
(3, '‎زهرة صباح الخير - (Portulaca grandiflora flower)', 0x696d672f6f7574646f6f722f332e6a7067, 188, 12),
(4, 'زهرة لويزة - (Verbena flower)', 0x696d672f6f7574646f6f722f342e6a7067, 200, 12),
(5, 'زهرة البنتاس - (Prntas flower)', 0x696d672f6f7574646f6f722f352e6a7067, 79, 15),
(6, 'شجرة الريحان - (Basil tree)', 0x696d672f6f7574646f6f722f362e6a7067, 140, 15),
(7, 'شجرة الزيتون - (Olive tree)', 0x696d672f6f7574646f6f722f372e6a7067, 306, 15),
(8, 'شجرة الفيكس - ‎‎(Ficus tree)', 0x696d672f6f7574646f6f722f382e6a7067, 246, 15),
(9, 'شجرة النيم - (Neem tree)', 0x696d672f6f7574646f6f722f392e6a7067, 378, 10),
(10, '‎‎بونساي - (Bonsai)', 0x696d672f6f7574646f6f722f31302e6a7067, 115, 10),
(11, 'شجرة الحمضيات - ‎(Fruitful citrus tree)', 0x696d672f6f7574646f6f722f31312e6a7067, 320, 10),
(12, 'شجرة الليمون - (Lemon tree)', 0x696d672f6f7574646f6f722f31322e6a7067, 290, 10),
(13, 'افندر - (Lavender)', 0x696d672f6f7574646f6f722f31332e6a7067, 121, 15),
(14, 'جلد النمر الاخضر - ‎‎‎(Green leopard skin plant', 0x696d672f6f7574646f6f722f31342e6a7067, 189, 10),
(15, 'زهرة اللانتانا - (Lantana flower)', 0x696d672f6f7574646f6f722f31352e6a7067, 139, 0),
(16, 'جلد النمر الاسود - (Black leopard skin plant)', 0x696d672f6f7574646f6f722f31362e6a7067, 190, 0);

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `payment_id` int(5) NOT NULL,
  `payment_method` varchar(500) NOT NULL,
  `card_number` varchar(25) NOT NULL,
  `NameOnCard` varchar(500) NOT NULL,
  `month` int(2) NOT NULL,
  `year` int(4) NOT NULL,
  `security_code` varchar(3) NOT NULL,
  `total` int(5) NOT NULL,
  `Cust_id` int(15) NOT NULL,
  `Planter_id` int(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`payment_id`, `payment_method`, `card_number`, `NameOnCard`, `month`, `year`, `security_code`, `total`, `Cust_id`, `Planter_id`) VALUES
(1, 'Apple Pay', '88933', 'Nadenoo', 11, 2023, '123', 35, 2, 0),
(2, 'Credit Card', '55', 'nnn', 23, 2023, '123', 140, 2, 0),
(3, 'Credit Card', '1234', 'aloosh', 11, 2023, '123', 379, 0, 2),
(4, 'Cash On Delivery', '', '', 0, 0, '', 256, 4, 0),
(5, 'Cash On Delivery', '', '', 0, 0, '', 256, 0, 2),
(6, 'Credit Card', '9876', 'fghj', 99, 1239, '123', 193, 0, 2),
(7, 'Cash On Delivery', '', '', 0, 0, '', 0, 4, 0),
(8, 'Cash On Delivery', '', '', 0, 0, '', 99, 4, 0),
(9, 'Cash On Delivery', '', '', 0, 0, '', 32, 4, 0),
(10, 'Cash On Delivery', '', '', 0, 0, '', 32, 4, 0),
(11, 'Cash On Delivery', '', '', 0, 0, '', 89, 4, 0),
(12, 'Cash On Delivery', '', '', 0, 0, '', 89, 4, 0),
(13, 'Cash On Delivery', '', '', 0, 0, '', 166, 4, 0),
(14, 'Cash On Delivery', '', '', 0, 0, '', 166, 4, 0),
(15, 'Cash On Delivery', '', '', 0, 0, '', 69, 4, 0),
(16, 'Cash On Delivery', '', '', 0, 0, '', 165, 4, 0),
(17, 'Cash On Delivery', '', '', 0, 0, '', 165, 4, 0),
(18, 'Cash On Delivery', '', '', 0, 0, '', 189, 4, 0),
(19, 'Cash On Delivery', '', '', 0, 0, '', 189, 4, 0),
(20, 'Credit Card', '245678892000022', 'Zainab A Shamrookh', 9, 2025, '232', 444, 5, 0);

-- --------------------------------------------------------

--
-- Table structure for table `planter`
--

CREATE TABLE `planter` (
  `Planter_id` int(15) NOT NULL,
  `P_Fname` varchar(25) NOT NULL,
  `P_Lname` varchar(25) NOT NULL,
  `P_email` varchar(30) NOT NULL,
  `P_phone` varchar(15) NOT NULL,
  `P_birthdate` date NOT NULL,
  `P_Address` varchar(500) NOT NULL,
  `Password` varchar(30) NOT NULL,
  `P_Gender` varchar(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `planter`
--

INSERT INTO `planter` (`Planter_id`, `P_Fname`, `P_Lname`, `P_email`, `P_phone`, `P_birthdate`, `P_Address`, `Password`, `P_Gender`) VALUES
(1, 'Amaar', 'Aljasim', 'am12@gmail.com', '+966543877643', '1997-02-21', 'AlHufuf', 'Ammar@12', 'Male'),
(2, 'Osamah', 'Albayat', 'Os@gmail.com', '+966578988776', '1996-03-09', 'Mubarazz', 'Oss123456@', 'Male'),
(3, 'Abdulaziz', 'AlAnsari', 'Aziz22@gmail.com', '+966524288963', '2000-11-04', 'Alqarah', 'Aziz1234@', 'Male');

-- --------------------------------------------------------

--
-- Table structure for table `productorderedhistory`
--

CREATE TABLE `productorderedhistory` (
  `OH_id` int(3) NOT NULL,
  `O_id` int(3) NOT NULL,
  `I_id` int(3) NOT NULL,
  `T_id` int(3) NOT NULL,
  `Customer_id` int(15) NOT NULL,
  `Planter_id` int(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `productorderedhistory`
--

INSERT INTO `productorderedhistory` (`OH_id`, `O_id`, `I_id`, `T_id`, `Customer_id`, `Planter_id`) VALUES
(1, 0, 2, 0, 2, 0),
(2, 0, 2, 0, 2, 0),
(3, 0, 2, 0, 2, 0),
(4, 0, 2, 0, 2, 0),
(5, 0, 2, 0, 2, 0),
(6, 0, 4, 0, 2, 0),
(7, 0, 4, 0, 2, 0),
(8, 0, 4, 0, 2, 0),
(9, 0, 4, 0, 2, 0),
(10, 0, 4, 0, 2, 0),
(11, 0, 3, 0, 2, 0),
(12, 0, 2, 0, 2, 0),
(13, 0, 0, 2, 2, 0),
(14, 0, 0, 2, 2, 0),
(15, 0, 0, 2, 2, 0),
(16, 0, 11, 0, 0, 2),
(17, 0, 11, 0, 0, 2),
(18, 13, 0, 0, 0, 2),
(19, 13, 0, 0, 0, 2),
(20, 0, 0, 18, 0, 2),
(21, 0, 1, 0, 4, 0),
(22, 0, 4, 0, 4, 0),
(23, 0, 0, 1, 4, 0),
(24, 0, 1, 0, 4, 0),
(25, 1, 0, 0, 4, 0),
(26, 0, 0, 1, 4, 0),
(27, 0, 1, 0, 0, 2),
(28, 1, 0, 0, 0, 2),
(29, 0, 0, 1, 0, 2),
(30, 0, 2, 0, 0, 2),
(31, 2, 0, 0, 0, 2),
(32, 0, 0, 2, 0, 2),
(33, 0, 1, 0, 4, 0),
(34, 0, 1, 0, 4, 0),
(35, 0, 15, 0, 4, 0),
(36, 0, 15, 0, 4, 0),
(37, 0, 18, 0, 4, 0),
(38, 0, 18, 0, 4, 0),
(39, 1, 0, 0, 4, 0),
(40, 0, 0, 23, 4, 0),
(41, 0, 0, 21, 4, 0),
(42, 0, 0, 19, 4, 0),
(43, 0, 0, 23, 4, 0),
(44, 0, 0, 21, 4, 0),
(45, 0, 0, 19, 4, 0),
(46, 0, 0, 23, 4, 0),
(47, 0, 0, 1, 4, 0),
(48, 1, 0, 0, 4, 0),
(49, 14, 0, 0, 4, 0),
(50, 14, 0, 0, 4, 0),
(51, 0, 2, 0, 5, 0),
(52, 0, 3, 0, 5, 0),
(53, 2, 0, 0, 5, 0),
(54, 3, 0, 0, 5, 0),
(55, 0, 0, 2, 5, 0),
(56, 0, 0, 3, 5, 0),
(57, 3, 0, 0, 5, 0);

-- --------------------------------------------------------

--
-- Table structure for table `rating`
--

CREATE TABLE `rating` (
  `Rate_id` int(11) NOT NULL,
  `Rating_Value` int(3) NOT NULL,
  `C_ID` int(15) NOT NULL,
  `P_ID` int(15) NOT NULL,
  `O_ID` int(3) NOT NULL,
  `I_ID` int(3) NOT NULL,
  `T_ID` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `rating`
--

INSERT INTO `rating` (`Rate_id`, `Rating_Value`, `C_ID`, `P_ID`, `O_ID`, `I_ID`, `T_ID`) VALUES
(1, 5, 2, 0, 0, 2, 0),
(2, 5, 2, 0, 0, 2, 0),
(3, 2, 2, 0, 0, 2, 0),
(4, 1, 2, 0, 0, 3, 0),
(5, 3, 2, 0, 0, 3, 0),
(6, 5, 2, 0, 0, 3, 0),
(7, 5, 2, 0, 0, 3, 0),
(8, 1, 2, 0, 0, 3, 0),
(9, 1, 2, 0, 0, 3, 0),
(10, 1, 2, 0, 0, 3, 0),
(11, 1, 2, 0, 0, 3, 0),
(12, 1, 2, 0, 0, 3, 0),
(13, 1, 2, 0, 0, 3, 0),
(14, 1, 2, 0, 0, 2, 0),
(15, 5, 0, 2, 0, 11, 0),
(16, 5, 4, 0, 0, 1, 0),
(17, 5, 4, 0, 0, 4, 0),
(18, 2, 4, 0, 0, 4, 0),
(19, 2, 4, 0, 0, 4, 0),
(20, 1, 4, 0, 0, 1, 0),
(21, 1, 4, 0, 0, 1, 0),
(22, 1, 4, 0, 0, 1, 0),
(23, 4, 4, 0, 0, 15, 0),
(24, 4, 4, 0, 0, 0, 1),
(25, 2, 4, 0, 0, 0, 1),
(26, 4, 4, 0, 14, 0, 0),
(27, 3, 4, 0, 14, 0, 0),
(28, 5, 5, 0, 0, 2, 0),
(29, 1, 5, 0, 0, 3, 0),
(30, 3, 5, 0, 2, 0, 0),
(31, 2, 5, 0, 3, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE `services` (
  `S_id` int(3) NOT NULL,
  `S_title` varchar(500) NOT NULL,
  `S_img` blob NOT NULL,
  `S_price` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`S_id`, `S_title`, `S_img`, `S_price`) VALUES
(1, 'Planting outdoor plants and trees', 0x696d672f53657276696365732f312e6a7067, 150),
(2, 'Organize the garden only', 0x696d672f53657276696365732f322e6a7067, 230),
(3, 'Organize the garden by adding 3 plants of your choice', 0x696d672f53657276696365732f332e6a7067, 270),
(4, 'Organize the garden by adding 5 plants of your choice', 0x696d672f53657276696365732f342e6a7067, 310),
(5, 'Preview planting place - When you purchase plants from our store, and our planters will plant your garden, preview will be free.', 0x696d672f53657276696365732f352e6a7067, 100);

-- --------------------------------------------------------

--
-- Table structure for table `servicesorders`
--

CREATE TABLE `servicesorders` (
  `Ord_ID` int(3) NOT NULL,
  `S_id` int(3) NOT NULL,
  `S_status` varchar(50) NOT NULL,
  `Cust_id` int(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tools`
--

CREATE TABLE `tools` (
  `T_id` int(5) NOT NULL,
  `T_title` varchar(500) NOT NULL,
  `T_img` blob NOT NULL,
  `T_price` float NOT NULL,
  `T_quantity` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tools`
--

INSERT INTO `tools` (`T_id`, `T_title`, `T_img`, `T_price`, `T_quantity`) VALUES
(1, 'wooden plant pot suitable for indoor and outdoor plants', 0x696d672f546f6f6c732f312e6a7067, 155, 20),
(2, 'A hanging stone plant pot attached to a wooden base', 0x696d672f546f6f6c732f322e6a7067, 99.5, 11),
(3, 'Safer 3in1 Organic Pesticide for Plants and Garden + Indoor Home Insecticide Spray', 0x696d672f546f6f6c732f332e6a7067, 43, 13),
(4, 'soil moisture meter for garden', 0x696d672f546f6f6c732f342e6a7067, 65, 15),
(5, 'Hand-painted plant pot decorated with flowers', 0x696d672f546f6f6c732f352e6a7067, 60, 15),
(6, 'A set of plant pots consisting of 4 pcs in matching colors, Suitable for small indoor plants', 0x696d672f546f6f6c732f362e6a7067, 90, 15),
(7, 'Pottery sprinkler for plants', 0x696d672f546f6f6c732f372e6a7067, 35, 10),
(8, 'Nursery Bags (grow bags 50 pcs). Supplies for Vegetable Flower Fruit Saplings', 0x696d672f546f6f6c732f382e6a7067, 30, 10),
(9, 'Indoor Plant Fertilizer - Liquid Nutrients for Houseplants', 0x696d672f546f6f6c732f392e6a7067, 55, 10),
(10, 'Stone plant pot designed for outdoor plants with a modern design and resistant to moisture and weather heat', 0x696d672f546f6f6c732f31302e6a7067, 200, 10),
(11, 'Garden Tools Set 8 pieces with bag', 0x696d672f546f6f6c732f31312e6a7067, 120, 10),
(12, 'Handmade plant pot made of palm leaves', 0x696d672f546f6f6c732f31322e6a7067, 53, 10),
(13, 'Hydroponics growing system', 0x696d672f546f6f6c732f31362e6a7067, 480, 10),
(14, 'Plant pot with glass bottom', 0x696d672f546f6f6c732f32312e6a7067, 84, 10),
(15, 'Pot automatic watering pants', 0x696d672f546f6f6c732f32322e6a7067, 114, 10),
(16, 'Automatic watering system for plants', 0x696d672f546f6f6c732f32332e6a7067, 98, 10),
(17, 'Garden Lawn Automatic Lawn Water Sprinklers.', 0x696d672f546f6f6c732f32342e6a7067, 180, 10),
(18, 'FERTIL-Indoor Plant Fertilizer - fertil olivi E Agrumi 25 L. Specific growing for olive trees and citrus fruits. Completely organic fertilizer, healthy and able to support plant nutrition for a long period.', 0x696d672f546f6f6c732f32352e6a7067, 100, 15),
(19, 'Stone plant pot colored olive green and dotted with several colors.', 0x696d672f546f6f6c732f31382e6a7067, 70, 10),
(20, 'Stone plant pot colored rouge pink and dotted with several colors.', 0x696d672f546f6f6c732f31372e6a7067, 70, 10),
(21, 'Modern design manual plant sprayer (white)', 0x696d672f546f6f6c732f31392e6a7067, 45, 10),
(22, 'Modern design manual plant sprayer (dark green)', 0x696d672f546f6f6c732f32302e6a7067, 45, 15),
(23, 'Unique plant pot (light blue)', 0x696d672f546f6f6c732f31332e6a7067, 50, 10),
(24, 'Unique plant pot (light grey)', 0x696d672f546f6f6c732f31342e6a7067, 50, 10),
(25, 'Unique plant pot (beige)', 0x696d672f546f6f6c732f31352e6a7067, 50, 15);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `advices`
--
ALTER TABLE `advices`
  ADD PRIMARY KEY (`A_id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`cart_id`);

--
-- Indexes for table `cartnotlogin`
--
ALTER TABLE `cartnotlogin`
  ADD PRIMARY KEY (`cart_id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`Customer_id`);

--
-- Indexes for table `indoor`
--
ALTER TABLE `indoor`
  ADD PRIMARY KEY (`I_id`);

--
-- Indexes for table `outdoor`
--
ALTER TABLE `outdoor`
  ADD PRIMARY KEY (`O_id`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`payment_id`);

--
-- Indexes for table `planter`
--
ALTER TABLE `planter`
  ADD PRIMARY KEY (`Planter_id`);

--
-- Indexes for table `productorderedhistory`
--
ALTER TABLE `productorderedhistory`
  ADD PRIMARY KEY (`OH_id`);

--
-- Indexes for table `rating`
--
ALTER TABLE `rating`
  ADD PRIMARY KEY (`Rate_id`);

--
-- Indexes for table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`S_id`);

--
-- Indexes for table `servicesorders`
--
ALTER TABLE `servicesorders`
  ADD PRIMARY KEY (`Ord_ID`);

--
-- Indexes for table `tools`
--
ALTER TABLE `tools`
  ADD PRIMARY KEY (`T_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `advices`
--
ALTER TABLE `advices`
  MODIFY `A_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `cart_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT for table `cartnotlogin`
--
ALTER TABLE `cartnotlogin`
  MODIFY `cart_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `Customer_id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `indoor`
--
ALTER TABLE `indoor`
  MODIFY `I_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `outdoor`
--
ALTER TABLE `outdoor`
  MODIFY `O_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `payment_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `planter`
--
ALTER TABLE `planter`
  MODIFY `Planter_id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `productorderedhistory`
--
ALTER TABLE `productorderedhistory`
  MODIFY `OH_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=58;

--
-- AUTO_INCREMENT for table `rating`
--
ALTER TABLE `rating`
  MODIFY `Rate_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `services`
--
ALTER TABLE `services`
  MODIFY `S_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `servicesorders`
--
ALTER TABLE `servicesorders`
  MODIFY `Ord_ID` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tools`
--
ALTER TABLE `tools`
  MODIFY `T_id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
