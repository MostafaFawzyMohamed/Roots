<?php
class my_mysqli
{
    // Mysqli connection initialization
    public $mconn = null;

    /**
     * Initialize our mysqli connection ($mconnn) object
     * when the database class is called
     */
	 
    public function __construct()
    {
        $databaseHost = 'localhost';
        $databaseName = 'roots';
        $databaseUsername = 'root';
        $databasePassword = '';

        // In the construction method, we simply set our
        // Mysql Connection object.
        $this->mconn = mysqli_connect($databaseHost, $databaseUsername, $databasePassword, $databaseName);
        if (mysqli_connect_errno()) {
            printf("%s \n", mysqli_connect_error());
            exit();
        }
    }
	public function last_id()
    {
        return mysqli_insert_id($this->mconn);
    }
    
	public function exec_query($qry)
    {
        $stmt = mysqli_query($this->mconn, $qry);
        if (mysqli_affected_rows($this->mconn) > 0) {
            return true;
        } else {
            return false;
        }
    }
	
}

?>